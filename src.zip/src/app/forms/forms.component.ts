import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  constructor() { }

  appname ="cool";

  btnclick = false;
  activeFlag = false;

  handleme()
  {
    this.btnclick =true;
  }
 
collectstyle()
{
  return {
     'btn': true,
    'btn-primary': true,
    'btn-extra-class': this.activeFlag
}
}
toggleclass()
{
  console.log('toggle');
  this.activeFlag =  !this.activeFlag;
}
  ngOnInit() {
  }

}
